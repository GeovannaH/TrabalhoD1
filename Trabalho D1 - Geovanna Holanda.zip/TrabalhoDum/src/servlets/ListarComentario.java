package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Comentario;
import model.Noticia;
import service.ComentarioService;
import service.NoticiaService;



@WebServlet("/ListarComentario.do")
public class ListarComentario extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	}



	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//doGet(request, response);
		
		
		int id_noticia_comentario = Integer.parseInt(request.getParameter("idNoticia_comentario"));
		//String id_noticia_comentario = request.getParameter("idNoticia_comentario");
		String nome_comentario = request.getParameter("nome_comentario");
		String texto_comentario = request.getParameter("texto_comentario");
		
		
		
		//Instanciando um objeto Comentario:
		Comentario enviarComentario = new Comentario();
		
		//Intanciando um objeto Noticia para armazenar o valor Id da noticia:
		Noticia pegarId = new Noticia();
		
		//Armazenando os dados retirados do formul�rio de coment�rio em um Objeto Comentario:
		enviarComentario.setNome(nome_comentario);
		enviarComentario.setTexto(texto_comentario);
		enviarComentario.setId(0);
		
		
		//Armazenando o valor do Id da noticia em que o comentario foi feito em um Objeto Noticia
		pegarId.setId(id_noticia_comentario);
		
		//Armazenando o Objeto Noticia que contem o id da noticia em que o comentario foi feito no Objeto Comentario
		enviarComentario.setId_noticia(pegarId);
		
		
		//Acrescentar o id do Coment�rio a cada novo coment�rio:
		ComentarioService comentarioService = new ComentarioService();
		
		ArrayList<Comentario> listaComentarios = comentarioService.listarComentarios();
		listaComentarios = new ArrayList();
		listaComentarios.add(enviarComentario);
		
		for (Comentario c : listaComentarios) {
			if (c.getId() == enviarComentario.getId()) {
				int aux = c.getId();
				enviarComentario.setId(aux + 1);			
			}
		}
		
		
		
		
		comentarioService.enviar(enviarComentario);
		
		//Redirecina o usu�rio:
		response.sendRedirect("ListarNoticias.do");
		
		
		//Criando o objeto de saida de dados:
		PrintWriter saida = response.getWriter();
		
		saida.println("Coment�rio Enviado!");
				
		//Imprimindo o teste para ver se armazenou corretamente!
/*		saida.println(enviarComentario.getId_noticia().getId());
		saida.println(enviarComentario.getNome());
		saida.println(enviarComentario.getTexto());
		saida.println(enviarComentario.getId());
*/
		
		
	}

}
