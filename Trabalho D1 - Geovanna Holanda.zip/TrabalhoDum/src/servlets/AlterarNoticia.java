package servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Noticia;
import service.NoticiaService;


@WebServlet("/AlterarNoticia.do")
public class AlterarNoticia extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //doGet(request, response);
		int novoId = Integer.parseInt(request.getParameter("id_form"));
		String novoTitulo = request.getParameter("titulo_form");
		String novaDescricao = request.getParameter("descricao_form");
		String novoTexto = request.getParameter("texto_form");
		
		Noticia noticiaAlterada = new Noticia();
		
		//Alterando os dados da Not�cia:
		noticiaAlterada.setId(novoId);
		noticiaAlterada.setTitulo(novoTitulo);
		noticiaAlterada.setDescricao(novaDescricao);
		noticiaAlterada.setTexto(novoTexto);
		
		//Alterando DE FATO os dados da Not�cia e enviando ao BD
		NoticiaService noticiaService = new NoticiaService();
		noticiaService.alterar(noticiaAlterada);
		
		//Criando objeto de saida de dados:
		PrintWriter saida = response.getWriter();
				
		saida.println("Not�cia Alterada!");
		
	}

}
