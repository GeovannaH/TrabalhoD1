package servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Noticia;
import service.NoticiaService;


@WebServlet("/InserirNoticia.do")
public class InserirNoticia extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	//	response.getWriter().append("Served at: ").append(request.getContextPath());
	
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	//	doGet(request, response);
		
		int id = Integer.parseInt(request.getParameter("id_form"));
		String titulo = request.getParameter("titulo_form");
		String descricao = request.getParameter("descricao_form");
		String texto = request.getParameter("texto_form");
		
		
		
		Noticia inserirNoticia = new Noticia();
		inserirNoticia.setId(id);
		inserirNoticia.setTitulo(titulo);
		inserirNoticia.setDescricao(descricao);
		inserirNoticia.setTexto(texto);
		
		NoticiaService noticiaService = new NoticiaService();
		noticiaService.inserir(inserirNoticia);
		
		//Criando objeto de saida de dados:
		PrintWriter saida = response.getWriter();
		
		saida.println("Not�cia Criada!");
	
	}

}
