package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.Comentario;
import model.Noticia;
import service.ComentarioService;
import service.NoticiaService;


@WebServlet("/EnviarComentario.do")
public class EnviarComentario extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//Captura os dados do formul�rio Coment�rio:
		//int id = Integer.parseInt(request.getParameter("id_form"));
		String nome = request.getParameter("nome_comentario");
		String texto = request.getParameter("texto_comentario");
		int id_noticia_comentario = Integer.parseInt(request.getParameter("idNoticia_comentario"));
		
		
		//Armazenando o Id de noticia informado em um objeto Noticia
		Noticia pegarId = new Noticia();
		pegarId.setId(id_noticia_comentario);
		
		
		//Criando um objeto Comentario e armazenando os dados nele
		Comentario enviarComentario = new Comentario();
		enviarComentario.setNome(nome);
		enviarComentario.setTexto(texto);
		enviarComentario.setId_noticia(pegarId);
		
		//Armazenando o valor 0 como valor de Id
		int valor_id = 0;
		enviarComentario.setId(valor_id);

		//Criando um objeto de sess�o do usu�rio:
		HttpSession sessao = request.getSession();
		
		ArrayList<Comentario> comentarios;
		
		if (sessao.getAttribute("lista_comentarios") == null) {
			comentarios = new ArrayList();
		} else {
			comentarios = (ArrayList) sessao.getAttribute("lista_comentarios");
		}
		
		
		comentarios.add(enviarComentario);
		
		for (Comentario c : comentarios) {
			
			if (c.getId() <= enviarComentario.getId()) {
				int auxUm = c.getId();
				int auxDois = c.getId();
				enviarComentario.setId(auxDois + 1);
				c.setId(auxUm);
				
			}
			
		}
		
	
		//Adicionando a lista de comentarios � sess�o:
		sessao.setAttribute("lista_comentarios", comentarios);
		
		ComentarioService comentarioService = new ComentarioService();
		comentarioService.enviar(enviarComentario);
		
		
		
		//Criando objeto de saida de dados:
		PrintWriter saida = response.getWriter();
		saida.println("Coment�rio Enviado!");
		
		
		//Redirecina o usu�rio:
		response.sendRedirect("ListarNoticias.do");
		
		
	}



}
