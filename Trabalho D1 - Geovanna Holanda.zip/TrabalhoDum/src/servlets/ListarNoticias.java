package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.Comentario;
import model.Noticia;
import service.ComentarioService;
import service.NoticiaService;


@WebServlet("/ListarNoticias.do")
public class ListarNoticias extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		
		
		NoticiaService noticiaService = new NoticiaService();
		
		ArrayList<Noticia> listaNoticias = noticiaService.listarNoticias();
		
		//Definir o tipo de conte�do da resposta:
		response.setContentType("text/html");
		response.setCharacterEncoding("UTF-8");
		
		//Criando o objeto de saida de dados:
		PrintWriter saida = response.getWriter();
		
		saida.println("<h1 style=\"font-family:arial\">RealNews</h1>"
				+ "<hr color=black>");
		
		for (Noticia n : listaNoticias) {
			
			saida.println("<h2 style=\"font-family:arial\">" 
					+ n.getTitulo() 
					+ " </h2>");
			saida.println("<p align=justify style=\"font-family:arial\">" + n.getTexto() + "</p>"
					+ "<hr color=#F8F8FF>");
			
			saida.println("<h3 style=\"font-family:arial\"> Coment�rios"
					+ "</h3>"
					);
			
	/*		saida.println("<form action=\"ListarComentario.do\" method=\"get\">" 
					+ "<input type=\"submit\" value=\"Visualizar Coment�rios\">"
					+ "</form>"
					+ "<form action=\"EnviarComentario.do\" method=\"post\">"
					+ "<input type=\"submit\" value=\"Enviar Coment�rio\">"
					+ "</form>"
					);
	*/		
			
			//Acessar a sess�o onde os coment�rios est�o:
			HttpSession sessao = request.getSession();
			
			//Ler os valores da sess�o:
			ArrayList<Comentario> comentarios = (ArrayList<Comentario>) sessao.getAttribute("lista_comentarios");
			
			if (comentarios == null) {
				saida.println("<label style=\"font-family:arial; font-size:14; color:#696969\"> <i> Sem coment�rios... </i> </label>"
						+ "<hr color=#EEE9E9>");
			} else {
				
				for (Comentario c : comentarios) {
					
					if (c.getId_noticia().getId() == n.getId()) {
						
						saida.println("<label style=\"font-family:arial\"> <b>" + c.getNome() + " </b> </label> <br>" 
								+ "<label style=\"font-family:arial; font-size:14\">" + c.getTexto() + "</label> <br>"
								+ "<hr color=#EEE9E9>");
						
					}
					
				}
				
			}
			
			
			
			
			
			
			saida.println("<form action=\"EnviarComentario.do\" method=\"post\">"
								//Ver o valor do id da Noticia (Teste - ok)
					+ "<input type=\"hidden\" name=\"idNoticia_comentario\" value=\"" + n.getId() + "\" > <br>"
					+ "<label style=\"font-family:arial\"> <b>Adicinar Coment�rio: </b> </label> <br> <br>"
					+ "<label style=\"font-family:arial; font-size:15\"> <b>Nome: </b> </label>"
					+ "<input type=\"text\" name=\"nome_comentario\" size=\"50\"> <br> <br>"
					+ "<label style=\"font-family:arial; font-size:15\"> <b>Coment�rio: </b> </label>"
					+ "<textarea name=\"texto_comentario\" rows=\"3\" cols=\"50\"></textarea> <br> <br>"
					+ "<input type=\"submit\" value=\"Enviar\">"
					+ "</form>"
					
					+ "<hr color=#D3D3D3>"
					+ "<hr color=#D3D3D3>"
					);
			
		}
		
		
	
		
	}

}
