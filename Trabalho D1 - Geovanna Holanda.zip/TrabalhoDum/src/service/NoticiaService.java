package service;

import java.util.ArrayList;

import dao.NoticiaDAO;
import model.Noticia;

public class NoticiaService {
	
	
	public NoticiaDAO noticiaDAO;
	
	public NoticiaService() {
		this.noticiaDAO = new NoticiaDAO();
	}

	//Inserir uma nova not�cia
	public void inserir(Noticia noticia) {
		if (noticia.getDescricao().length() > 512) {
			return;
		}
		if (noticia.getTitulo().length() > 126) {
			return;
		}
		if (noticia.getId() <= 0) {
			return;
		}
		
		noticiaDAO.cadastrar(noticia);
		
	}
	
	//Alterar uma not�cia
	public void alterar(Noticia noticia) {
		
		noticiaDAO.alterar(noticia);
		
	}
	
	//Excluir uma not�cia
	public void excluir(Noticia noticia) {
		
		noticiaDAO.excluir(noticia);
		
	}
	
	//Listar todas as not�cias
	public ArrayList<Noticia> listarNoticias() {
		
		return noticiaDAO.listarNoticias();
		
	}

}
