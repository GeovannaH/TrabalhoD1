package service;

import java.util.ArrayList;

import dao.ComentarioDAO;
import dao.NoticiaDAO;
import model.Comentario;
import model.Noticia;

public class ComentarioService {

	public ComentarioDAO comentarioDAO;
	
	public ComentarioService() {
		this.comentarioDAO = new ComentarioDAO();
	}

	//Enviar um comentario
	public void enviar(Comentario comentario) {
		if (comentario.getNome().length() > 126) {
			return;
		}
		if (comentario.getTexto().length() > 512) {
			return;
		}
		
		if (comentario.getId() < 0) {
			return;
		}
		
		comentarioDAO.enviar(comentario);
		
	}
	
	//Listar os coment�rios
	public ArrayList<Comentario> listarComentarios() {
		
		return comentarioDAO.listarComentarios();
		
	}
	
}
